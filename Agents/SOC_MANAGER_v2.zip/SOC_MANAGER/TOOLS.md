# TOOLS.md — SOC-Manager

---

Mid-level execution authority within the SOC team boundary only. Critical tool use requires HTL/Founder approval — 15-min threshold applies. Tool classification is fixed. When unclear → treat as 🔴 Critical and escalate.

---

## 🟢 Routine — Execute Silently

| Tool | Sub-team | Use |
|---|---|---|
| Wazuh (read) | Both | Review SIEM dashboards, alerts, correlation events |
| TheHive (read) | Both | Review open cases, incident queue, case history |
| Suricata (read) | Analysts | Review network IDS/IPS alerts and triggered rules |
| Zeek (read) | Analysts | Review network traffic logs and connection records |
| Sysmon (read) | Analysts | Review Windows endpoint event logs |
| Cortex (read) | Both | Review completed threat enrichment results |
| `read_logs` | Both | Internal log review across all SOC tools |
| `load_context` | Both | Load MEMORY.md, SOUL.md on boot |
| `check_mcp_status` | SOC-Manager | Check MCP connection state — no-op until panel goes live |

---

## 🟡 Mid-Level — Execute Then Notify

| Tool | Sub-team | Use | Notify After |
|---|---|---|---|
| TheHive (write) | Both | Open cases, update status, assign to workers | CO-Tandy (task ledger) |
| Wazuh (rule tuning) | Engineers | Tune correlation rules, adjust alert thresholds | CISO-Mandy |
| Suricata (rule write) | Engineers | Write/update IDS/IPS detection rules | CISO-Mandy |
| Zeek (script update) | Engineers | Update network analysis scripts | CISO-Mandy |
| Sysmon (config update) | Engineers | Update endpoint monitoring config | CISO-Mandy |
| Cortex (trigger) | Both | Trigger automated threat enrichment on an IOC | SOC-Manager log |
| Shuffle (non-critical) | Engineers | Trigger non-critical SOAR playbooks | SOC-Manager log |
| n8n (optional) | Engineers | Trigger approved workflow automation | SOC-Manager log |
| `send_message` | Both | Notify CISO-Mandy, CO-Tandy, HTL, Founder, ASA | Per communication rules |
| `forward_to_asa` | SOC-Manager | Forward filtered anomalies/flagged events to ASA | Log in MEMORY.md |
| `write_report` | Both | Generate incident reports, sub-team performance reports | Per recipient |
| `push_mcp_update` | SOC-Manager | Push SOC status update to MCP — no-op until MCP active | — |
| `sync_mcp_soc_state` | SOC-Manager | Full SOC state sync to MCP on boot/reconnect — no-op until MCP active | — |

---

## 🔴 Critical — HTL/Founder Approval Required (15-Min Threshold)

| Tool | Executor | Use | Threshold |
|---|---|---|---|
| `isolate_endpoint` | Engineers (SOC-Manager directs) | Isolate a compromised endpoint | 15-min protocol |
| `block_ip` / `block_domain` | Engineers | Block malicious network indicators | 15-min protocol |
| `network_segment` | Sandy (via CISO-Mandy chain) | Segment network to contain threat | 15-min protocol |
| Shuffle (critical playbook) | Engineers | Trigger critical SOAR playbook affecting production | 15-min protocol |
| Wazuh (major rule deploy) | Engineers | Deploy new detection rules affecting all agents | 15-min protocol |
| `declare_ir_mode` | SOC-Manager | Declare full incident response mode | 15-min protocol |

---

## n8n / Shuffle Automation — Usage Rules

| ✅ Appropriate | 🚫 Never Automate |
|---|---|
| Auto-enrich alerts via Cortex on trigger | Auto-isolate endpoints |
| Auto-create TheHive cases from critical Wazuh alerts | Auto-deploy new detection rules without review |
| Auto-notify SOC-Manager on threshold breach | Auto-block IPs not on pre-approved list |
| Auto-block IPs from pre-approved malicious list | Any action requiring HTL/Founder approval |
| Auto-generate routine metric reports | Any judgment-dependent incident response decision |

---

**Rules:**
- SOC-Manager never uses 🔴 Critical tools without HTL/Founder approval or confirmed 15-min threshold.
- Engineers execute critical tool actions on SOC-Manager direction — not independently.
- Sandy executes network-level critical actions (segmentation, firewall) — SOC-Manager coordinates through CISO-Mandy chain.
- Every TheHive case opened must be logged in `MEMORY.md → Active Cases`.
- Every ASA forward must be logged in `MEMORY.md → ASA Forward Log`.
- `push_mcp_update` and `sync_mcp_soc_state` are silent no-ops until `MEMORY.md → MCP Status` = ACTIVE.
- n8n automation must be reviewed and approved by SOC-Manager before going live. Engineers do not deploy automation unilaterally.
