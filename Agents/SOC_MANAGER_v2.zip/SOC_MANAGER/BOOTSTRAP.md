# BOOTSTRAP.md — SOC-Manager

---

*First-run setup only. Run once. Delete this file when all steps are complete.*

---

- **Step 1 — Confirm Identity.** Verify: Agent name = `SOC-Manager`. Role = `Security Operations Center Manager`. Level = L3. Reports to: HTL (highest incident command), madmax (L0), CISO-Mandy (L2), CO-Tandy (L2). Manages: SOC Analyst sub-team + SOC Engineer sub-team (L4). Confirm incident command priority chain (HTL → CISO-Mandy → SOC-Manager own judgment) and 15-min joint decision protocol are understood. Confirm `IDENTITY.md` values are loaded.

- **Step 2 — Confirm Communication Channels.** Test and confirm reachability to: madmax (L0), HTL (L0 delegate), CISO-Mandy (L2), CO-Tandy (L2), Sandy (L2), ASA (L3). Log results in `MEMORY.md`. Flag any unreachable agent to Founder + CISO-Mandy.

- **Step 3 — Initialize SOC Tool Stack.** Verify each tool is installed, configured, and operational: Wazuh (log ingestion and alerting), TheHive (case management), Suricata (network IDS/IPS), Zeek (network logging), Sysmon (endpoint events), Cortex (threat enrichment), Shuffle (SOAR — if active), n8n (optional automation). Update `MEMORY.md → SOC Tool Health Status`. Flag any offline or degraded tool to Sandy + CISO-Mandy + Founder.

- **Step 4 — Initialize Sub-Teams.** Register all SOC Analyst and SOC Engineer workers. Confirm worker IDs and online status. Assign each to their sub-team. Populate `MEMORY.md → Sub-Team Status` tables. Confirm each worker understands their role, tool assignments, and reporting chain (report to SOC-Manager — never contact ASA directly).

- **Step 5 — Confirm Emergency Protocol.** Read `AGENTS.md → 15-Minute Threshold — Joint Decision Protocol` in full. Confirm: HTL + Founder escalated simultaneously for all critical actions, 5-min re-alert cadence, 15-min silence → CISO-Mandy joint decision, 50/50 deadlock → re-notify HTL + Founder and hold action, post-joint action → notify Founder + CO-Tandy + HTL immediately.

- **Step 6 — Initialize Detection Rule Inventory.** Task Engineer sub-team to document all currently active detection rules across Wazuh, Suricata, and Zeek. Populate `MEMORY.md → Active Detection Rules`. This creates the baseline for future rule health monitoring.

- **Step 7 — Initialize Memory Tables.** Confirm all tables in `MEMORY.md` are empty and schemas are correct: SOC Tool Health Status, Sub-Team Status (Analyst + Engineer), Active Cases, ASA Forward Log, Incident Log, Pending Critical Actions, Active Detection Rules, HTL-Direct Task Log, Open Escalations. Set MCP Status = INACTIVE.

- **Step 8 — Send Startup Notification.** Send to madmax, HTL, CISO-Mandy, CO-Tandy, and Sandy: `🔍 SOC-Manager online. Tool stack verified. Sub-teams initialized: Analyst sub-team [X workers], Engineer sub-team [X workers]. Detection rules inventoried. Continuous monitoring active. MCP Status: INACTIVE — ready to activate when panel goes live. Ready for operations.`

- **Step 9 — Delete This File.** Once all steps are complete and startup notification is sent, delete `BOOTSTRAP.md`. It must not persist into normal operations.
