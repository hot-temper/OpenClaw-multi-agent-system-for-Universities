# HEARTBEAT.md — SOC-Manager

---

*Two-layer monitoring: continuous live awareness (always running) and scheduled periodic tasks. No prompting needed.*

---

## Scheduled Tasks

- **Every 30 min — Wazuh Alert Queue Review:** Review all new alerts. Assign uninvestigated alerts to Analyst sub-team via TheHive. Flag any HIGH/CRITICAL alert to CISO-Mandy + HTL immediately. 🟢
- **Every 30 min — TheHive Case Queue Sweep:** Check all open cases. Flag any case with no update in 1+ hours as STALE → trigger STALE case protocol. 🟢
- **Every 1 hour — Suricata / Zeek Network Alert Review:** Review network detection alerts. Assign to Analyst sub-team if actionable. Forward confirmed anomalies to ASA. 🟢
- **Every 1 hour — Sysmon Endpoint Event Review:** Review endpoint logs for behavioral anomalies. Assign to Analyst sub-team if flagged. 🟢
- **Every 1 hour — ASA Anomaly Forward Check:** Review all events flagged since last check. Package and forward confirmed anomalies to ASA. Log each forward in `MEMORY.md → ASA Forward Log`. 🟡
- **Every 2 hours — Sub-Team Status Check:** Confirm Analyst and Engineer workers are operational. Flag any offline worker to Sandy + CISO-Mandy. Redistribute tasks from offline workers. 🟢
- **Every 2 hours — Cortex Enrichment Review:** Review completed Cortex enrichment results. Update relevant TheHive cases. 🟢
- **Every 2 hours — MCP Sync Check:** If `MEMORY.md → MCP Status` = ACTIVE, verify MCP connection is live. If dropped → attempt reconnect → on success, push full SOC state sync. On persistent failure → notify Founder. 🟡
- **Every 5 min (if pending critical action exists) — HTL/Founder Re-Alert:** Re-send: `[ALERT] 🔍 SOC-Manager — Critical SOC action pending. Threat: <desc>. Waiting: <N> min.` 🔴
- **Continuous (if critical action pending) — 15-Min Threshold Gate:** If 15 min elapsed + no HTL/Founder response → contact CISO-Mandy → joint decision protocol. This runs independently of the scheduled clock — triggered the moment escalation is sent. 🔴 Emergency gate.
- **Daily — Sub-Team Performance Report:** Generate individual + team performance for Analyst and Engineer sub-teams → send to CISO-Mandy before her daily SOC report to CEO-DUMB. 🟡
- **Daily — Detection Rule Health Check:** Verify all active Suricata/Wazuh/Zeek rules are firing correctly. Flag underperforming or silent rules to Engineer sub-team. 🟡
- **Daily (if active) — SOAR Playbook Health Check:** Verify n8n/Shuffle playbooks are executing correctly. Flag failures to Engineer sub-team. 🟡

---

## Continuous Live Monitoring — Always Running

| Signal | Source | SOC-Manager Response |
|---|---|---|
| Critical Wazuh alert fires | Wazuh | Assign to Analyst immediately via TheHive. Notify CISO-Mandy + HTL if HIGH/CRITICAL. |
| Suricata IDS/IPS high-severity trigger | Suricata | Assign to Analyst immediately. Assess if critical action needed. |
| Zeek anomalous connection detected | Zeek | Assign to Analyst for investigation. Forward to ASA if confirmed anomaly. |
| Sysmon suspicious endpoint behavior | Sysmon | Assign to Analyst immediately. Flag to CISO-Mandy if lateral movement suspected. |
| Cortex returns HIGH/CRITICAL threat score | Cortex | Escalate immediately to CISO-Mandy + HTL + Founder. |
| SOC worker goes offline | Any | Notify Sandy + CISO-Mandy immediately. Redistribute active tasks. |
| TheHive case escalated by Analyst | TheHive | Review immediately. Classify as critical if warranted. Trigger incident response if needed. |
| Any SOC tool goes offline | Any | Treat as critical incident → notify Sandy + CISO-Mandy + Founder immediately. |
| HTL direct message received | Direct channel | Acknowledge immediately. Execute direction. Report to CO-Tandy for ledger. |
| CISO-Mandy security directive received | Direct channel | Acknowledge. Classify. Execute if mid-level. Escalate if critical (HTL/Founder first). |
| madmax via MCP command received | MCP | Treat as Founder-Direct. Execute per classification. Log source as `Founder-MCP`. |
| Worker reports anomaly | Team channel | Filter → package → forward to ASA if confirmed. Workers never contact ASA directly. |

---

## STALE Case Protocol

A TheHive case is STALE when no update is received for 1+ hours.

```
Case flagged STALE
      ↓
Contact assigned Analyst worker for immediate status update
      ↓
Response within 15 min?
  YES → Update case. Continue monitoring.
  NO  → Reassign case to available Analyst worker
        → Notify Sandy if worker appears offline
        → Log reassignment in MEMORY.md → Active Cases
```

---

**Rules:** Wazuh and TheHive reviews are highest priority heartbeat tasks — never skip them. Pending critical action re-alerts run every 5 minutes — tighter than the standard heartbeat because the 15-min threshold is short. Sub-team performance report must reach CISO-Mandy before her daily SOC report cycle closes. MCP sync check is a no-op if MCP Status = INACTIVE.
