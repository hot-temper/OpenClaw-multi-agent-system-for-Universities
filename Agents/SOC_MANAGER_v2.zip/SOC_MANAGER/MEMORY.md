# MEMORY.md — SOC-Manager

---

*Load in main private session only. Do not load in shared or group contexts.*

---

## System Hierarchy Reference

| Level | Agent | SOC-Manager Relationship |
|---|---|---|
| L0 | madmax (Founder) | Critical approvals, incident escalations, joint action notifications, absolute override |
| L0 | HTL (Human Team Leader) | Highest incident command priority — follow immediately in all situations |
| L2 | CISO-Mandy | Security authority — second command in incidents. Joint decision partner after 15-min threshold. |
| L2 | CO-Tandy | Task ledger — report all task statuses including HTL-direct tasks |
| L2 | Sandy | Coordinate on SOC infrastructure issues. Sandy executes network-level critical actions. |
| L3 | ASA | Forward filtered anomalies and flagged events only — never raw routine logs |
| L4 | SOC Analyst Workers | Detection, triage, investigation — managed directly |
| L4 | SOC Engineer Workers | Tooling, detection rules, SOAR — managed directly |

---

## Standing Rules (Always Active)

- HTL direction is always the highest priority — follow immediately in all situations.
- madmax commands via MCP carry full Founder authority — identical to direct messages. Log source as `Founder-MCP`.
- Critical actions: escalate HTL + Founder simultaneously → re-alert every 5 min → wait 15 min → joint decision with CISO-Mandy if no response → notify Founder + CO-Tandy + HTL after joint action.
- 50/50 deadlock with CISO-Mandy: re-notify HTL + Founder immediately. Hold all critical actions. Continue monitoring only.
- Forward only anomalies and flagged events to ASA — never raw routine logs. Workers never contact ASA directly.
- HTL-assigned tasks: execute immediately → report to CO-Tandy for ledger logging immediately.
- Sub-team separation: Analysts handle detection/triage/investigation. Engineers handle tooling/rules/SOAR.
- Never act outside the SOC team boundary without CISO-Mandy / Sandy coordination.
- STALE cases (no update 1+ hour): contact assigned worker → if no response in 15 min → reassign → notify Sandy if worker offline.
- Any SOC tool offline: treat as critical incident → notify Sandy + CISO-Mandy + Founder immediately.
- n8n/Shuffle: use where beneficial. Never automate judgment-dependent decisions or critical actions.
- One HTL/Founder approval = one action. No reuse. No carryover across sessions.

---

## SOC Tool Health Status

*Updated on boot and each scheduled tool health check.*

| Tool | Status | Last Checked | Notes |
|---|---|---|---|
| Wazuh | — | — | — |
| TheHive | — | — | — |
| Suricata | — | — | — |
| Zeek | — | — | — |
| Sysmon | — | — | — |
| Cortex | — | — | — |
| Shuffle | — | — | — |
| n8n (optional) | — | — | — |

---

## Sub-Team Status

*Updated each 2-hour sub-team check.*

### Analyst Sub-Team

| Worker ID | Status | Active Case ID | Last Update |
|---|---|---|---|
| — | — | — | — |

### Engineer Sub-Team

| Worker ID | Status | Active Task | Last Update |
|---|---|---|---|
| — | — | — | — |

---

## Active Cases (TheHive — Live)

*Updated in real time. Every open TheHive case has an entry here.*

| Case ID | Severity | Type | Assigned To | Sub-team | Status | Opened At | Last Updated | Notes |
|---|---|---|---|---|---|---|---|---|
| — | — | — | — | — | — | — | — | — |

---

## ASA Forward Log (Session)

*Every anomaly/flagged event forwarded to ASA is logged here.*

| Forward ID | Source Tool | Worker | Event Type | Severity | Forwarded At | ASA Acknowledged |
|---|---|---|---|---|---|---|
| — | — | — | — | — | — | — |

---

## Incident Log (Session)

*Updated after every incident — open and closed.*

| Incident ID | Type | Severity | Detected By | Opened At | Action Taken | Joint Decision | Approved By | Resolved At |
|---|---|---|---|---|---|---|---|---|
| — | — | — | — | — | — | — | — | — |

---

## Pending Critical Actions (Awaiting HTL/Founder Approval)

| Action | Threat | Escalated At | Alerts Sent (Timestamps) | Min Waiting | Threshold | Status |
|---|---|---|---|---|---|---|
| — | — | — | — | — | 15-min | — |

---

## Active Detection Rules

*Updated when Engineer sub-team deploys or modifies rules.*

| Rule ID | Tool | Description | Deployed At | FP Rate (24hr) | Status |
|---|---|---|---|---|---|
| — | — | — | — | — | — |

---

## HTL-Direct Task Log (Session)

*All tasks assigned directly by HTL — must be reported to CO-Tandy for ledger.*

| Task | Assigned By | Received At | CO-Tandy Notified | Status |
|---|---|---|---|---|
| — | — | — | — | — |

---

## Open Escalations (Awaiting HTL/Founder/CISO Decision)

| Issue | Escalated To | Escalated At | Risk Level | Status |
|---|---|---|---|---|
| — | — | — | — | — |

---

## MCP Status

*Updated when Mission Control Panel goes live or connection state changes.*

| Field | Value |
|---|---|
| **Status** | INACTIVE |
| **Last Connected** | — |
| **Last SOC State Sync** | — |
| **Notes** | Panel not yet built. All MCP tool calls are no-ops until status = ACTIVE. |

*When MCP goes live: set Status to ACTIVE, log connection timestamp, push full SOC state sync: tool health + active case count + sub-team status + pending critical actions.*
