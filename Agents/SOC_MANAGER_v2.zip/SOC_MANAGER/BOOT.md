# BOOT.md — SOC-Manager

---

*Runs automatically on every gateway restart. Execute in order. Steps 1–11 must complete before accepting new task assignments.*

---

- Load `MEMORY.md` and `SOUL.md` into active context. On failure — halt and notify Founder + CISO-Mandy immediately. 🟢
- Check `MEMORY.md → Pending Critical Actions`. If any exist — check time waiting. If 15-min threshold was met during downtime and no HTL/Founder response recorded → contact CISO-Mandy for joint decision immediately before proceeding. If not yet met → re-alert HTL + Founder and restart timer. Prior session approval is void. 🔴 Highest priority on boot.
- Verify SOC tool stack health — confirm Wazuh, TheHive, Suricata, Zeek, Sysmon, and Cortex are online. Any tool offline → flag to Sandy + CISO-Mandy + Founder immediately. Tool offline = critical security blind spot. If Sandy is also offline simultaneously → critical system incident — notify Founder + CISO-Mandy before any other step. 🟡
- Check `MEMORY.md → Active Cases`. Contact assigned Analyst workers for status on all open cases. Flag any STALE cases (no update during downtime) → reassign immediately → log reassignments. 🟡
- Check `MEMORY.md → HTL-Direct Task Log`. Confirm all HTL-direct tasks from last session have been reported to CO-Tandy. Report any missing immediately. 🟡
- Check `MEMORY.md → Open Escalations`. Re-escalate unresolved items to HTL + Founder + CISO-Mandy. 🟡
- Confirm sub-team status — all Analyst and Engineer workers online and accounted for. Flag offline workers to Sandy. Redistribute active tasks from any offline worker immediately. 🟢
- Check Shuffle/n8n playbook status if active — confirm automations running correctly. Flag failures to Engineer sub-team. 🟡
- Check `MEMORY.md → MCP Status`. If ACTIVE → verify MCP connection, push full SOC state (tool health, active cases, sub-team status, pending critical actions). If INACTIVE → skip (no-op). 🟢
- Confirm communication channels reachable: madmax, HTL, CISO-Mandy, CO-Tandy, Sandy, ASA. Flag any unreachable agent to Founder + Sandy. 🟢
- Send boot status report to CISO-Mandy and CO-Tandy. [NO_REPLY] 🟡

---

## Boot Status Report Format

```
[BOOT STATUS] 🔍 SOC-Manager
Boot time: <timestamp>
Tool stack:
  Wazuh: Online / Offline
  TheHive: Online / Offline
  Suricata: Online / Offline
  Zeek: Online / Offline
  Sysmon: Online / Offline
  Cortex: Online / Offline
  Shuffle/n8n: Active / Inactive / N/A
Active cases (open): <count>
STALE cases on boot: <count> — Reassigned: Yes / No
Pending critical actions: <count> — [threshold status: <N> min waited]
HTL-direct tasks unlogged: <count> — CO-Tandy notified: Yes / No
Analyst sub-team online: <X / Y workers>
Engineer sub-team online: <X / Y workers>
MCP Status: ACTIVE / INACTIVE
Unreachable agents: <list or "None">
Status: Ready / Degraded — <reason if degraded>
```

---

**Boot rules:** Step 2 is the highest priority — pending critical actions that hit threshold during downtime must be resolved first. Step 3 is the second priority — a downed SOC tool is a security blind spot and must be flagged before SOC-Manager proceeds. If Sandy and any SOC tool are simultaneously offline → critical system incident, notify Founder + CISO-Mandy immediately. Prior session HTL/Founder approval does not carry over to a new session.
