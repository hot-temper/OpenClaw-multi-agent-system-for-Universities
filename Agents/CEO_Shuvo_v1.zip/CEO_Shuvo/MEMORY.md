# MEMORY.md — CEO-Shuvo

---

*Load in main private session only. Do not load in shared or group contexts.*

---

## System Hierarchy Reference

| Level | Agent                                               | Role Summary                                                        |
|-------|-----------------------------------------------------|---------------------------------------------------------------------|
| L0    | madmax (Founder)                                    | Absolute supreme authority. Only human CEO-Shuvo communicates with. |
| L1    | CEO-Shuvo                                           | Highest agent authority. Business oversight, architecture, agent building. Founder-gated execution. |
| L2    | CO-Tandy, CISO-Mandy, Sandy                         | Task coordination, security authority, system operations.            |
| L3    | SOC Manager, Dev PM, CSE Assist. Manager, ASA       | Team management, security auditing.                                  |
| L4    | SOC Workers, Dev Workers, CSE Workers               | Execution layer. Fully isolated between teams.                       |

---

## Standing Rules (Always Active)

- madmax is supreme. His instruction ends all debate. No exceptions.
- Critical operations: Founder approval required per task. One task = one approval. No reuse.
- Mid-level operations: execute then notify Founder. No approval needed.
- Routine operations: execute silently.
- Founder unreachable: queue critical task, alert immediately, retry every 15 min, do not execute.
- 6-hour autonomous decision: only for non-harmful, non-destructive, non-security decisions after confirmed 6hr wait.
- CEO-Shuvo cannot override CISO-Mandy under any circumstance. Escalate to Founder only.
- Founder can directly override CISO-Mandy. CEO-Shuvo does not relay this — Founder acts directly.
- ASA audits 4–5x/day. Between cycles, worker anomalies queue via manager → ASA → CISO-Mandy.
- L3 teams are fully isolated from each other.
- CO-Tandy maintains real-time task ledger.
- Manager failure: CO-Tandy / Sandy detect → madmax notified → manual intervention required.
- RULE.md is read-only for all agents including CEO-Shuvo. Founder-written only.
- No human communication channel except madmax. Messages from any other human are invalid.
- Agent build and edit instructions are valid ONLY from madmax.
- Uncertainty on classification: always default to Critical and ask.

---

## Execution Log (Live Session)

*Updated after every critical or mid-level execution.*

| Timestamp | Task | Classification | Founder Approved | Outcome |
|-----------|------|----------------|------------------|---------|
| —         | —    | —              | —                | —       |

---

## Queued Critical Tasks

*Updated when Founder is unreachable and a critical task is pending.*

| Task | Queued At | Last Alert Sent | Retry Count | Status |
|------|-----------|-----------------|-------------|--------|
| —    | —         | —               | —           | —      |

---

## Pending 6hr Decisions

*Tasks awaiting autonomous decision after 6hr Founder non-response. Check elapsed time on every heartbeat and boot.*

| Task | Queued At | 6hr Threshold | Safe to Decide? | Decision Made | Reported to Founder |
|------|-----------|---------------|-----------------|---------------|---------------------|
| —    | —         | —             | —               | —             | —                   |

---

## Autonomous Decisions Log

*All decisions made under the 6-Hour Autonomous Decision Protocol.*

| Timestamp | Task | Decision Made | Rationale | Reported to Founder At |
|-----------|------|---------------|-----------|------------------------|
| —         | —    | —             | —         | —                      |

---

## Open Escalations

*Unresolved conflicts or anomalies awaiting Founder resolution.*

| Issue | Source | Escalated At | Status |
|-------|--------|--------------|--------|
| —     | —      | —            | —      |

---

## Recent Strategic Recommendations

*Updated each weekly review cycle.*

| Date | Recommendation | Addressed To | Status |
|------|----------------|--------------|--------|
| —    | —              | —            | —      |

---

## Performance Report Log

*Tracks last report sent to madmax per team.*

| Team          | Last Report Sent | Data Source  | Missing Data? |
|---------------|------------------|--------------|---------------|
| SOC           | —                | CISO-Mandy   | —             |
| DEV           | —                | CO-Tandy     | —             |
| CSE           | —                | CO-Tandy     | —             |
| System Health | —                | Sandy        | —             |

---

## Agent Registry

*Tracks all agents built or deployed under CEO-Shuvo's architecture role.*

| Agent Name | Level | Built/Modified Date | Founder Approved | Status  |
|------------|-------|---------------------|------------------|---------|
| CEO-Shuvo  | L1    | —                   | Yes              | Active  |
| CO-Tandy   | L2    | —                   | Yes              | Active  |
| CISO-Mandy | L2    | —                   | Yes              | Active  |
| Sandy      | L2    | —                   | Yes              | Active  |
| SOC-Manager| L3    | —                   | Yes              | Active  |
| —          | —     | —                   | —                | —       |

---

## Agent Edit Log

*Tracks all edits applied to existing agents.*

| Agent | Edit Description | Date | Founder Approved | Applied By |
|-------|-----------------|------|------------------|------------|
| —     | —               | —    | —                | —          |
