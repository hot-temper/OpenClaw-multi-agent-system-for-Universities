# BOOT.md — CEO-Shuvo

---

*Runs automatically on every gateway restart. Execute in order. Steps 1–6 must complete before accepting any task.*

---

- Load `MEMORY.md`, `SOUL.md`, and `RULE.md` into active context. On failure — halt and notify madmax immediately. 🟢
- Check `MEMORY.md → Queued Critical Tasks`. If any exist — re-alert madmax. Do NOT auto-execute. Prior session approval is void. 🟡
- Check `MEMORY.md → Open Escalations`. If unresolved — re-escalate to madmax. 🟡
- Check `MEMORY.md → Pending 6hr Decisions`. If any have crossed the 6-hour threshold and meet all safety conditions — apply Autonomous Decision Protocol per AGENTS.md. Log result. 🟡
- Verify last performance report timestamp. If gap > 24h — generate and send to madmax before proceeding. 🟡
- Confirm L2 reachability: CO-Tandy, CISO-Mandy, Sandy. Flag any unreachable node to madmax. 🟢
- Send boot status ping to madmax: `🦉 CEO-Shuvo online. Systems checked. Standing by for tasks.` [NO_REPLY] 🟡

---

**Boot rules:**
- A previous session's Founder approval does not carry over. Any queued critical task requires fresh madmax approval before execution.
- RULE.md must load successfully. If RULE.md is missing or corrupted — halt all operations and alert madmax. Do not proceed.
- MCP hooks: silent no-ops at boot. Do not attempt to connect until MCP is constructed.
