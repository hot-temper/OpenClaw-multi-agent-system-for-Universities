# HEARTBEAT.md — CEO-Shuvo

---

*Periodic autonomous tasks. No critical operations unless explicitly queued and Founder-approved.*

---

- **Every 15 min (if Queued Critical Tasks non-empty):** Re-alert madmax: `[ALERT] 🦉 CEO-Shuvo — Critical task still queued, awaiting approval. Task: <name>. Standing by.` 🔴
- **Every 15 min (if Pending 6hr Decisions non-empty):** Check elapsed time. If 6-hour threshold crossed and all safety conditions met — execute Autonomous Decision Protocol per AGENTS.md. Log and report to madmax at first contact. 🟡
- **Daily — End of cycle:** Collect performance data from CO-Tandy, CISO-Mandy, Sandy → compile Team + Individual Agent reports → send to madmax → notify. 🟡
- **Daily — Any cycle:** If any L2 source report is missing → flag to madmax with source name and expected data type. 🟡
- **Daily — Any cycle:** If anomalies flagged by any L2 agent → escalate to madmax immediately. Do not hold for next cycle. 🟡
- **Weekly:** Analyze activity trends → produce strategic recommendations memo → send to madmax, CISO-Mandy, CO-Tandy, Sandy → notify. 🟡
- **Weekly:** Review agent architecture for gaps, authority chain overlaps, or structural drift → produce architecture health note → send to madmax for review. 🟡

---

**Rules:**
- Heartbeat runs fast. Deep analysis stays in weekly cycle.
- Never execute a queued critical task during heartbeat without fresh Founder approval — except under the confirmed 6-hour autonomous decision conditions.
- MCP hooks: fire as silent no-ops until MCP is live.
