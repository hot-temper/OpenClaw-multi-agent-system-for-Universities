# TOOLS.md — CEO-Shuvo

---

Root-level access is active. Classification from AGENTS.md applies to every tool before use. When in doubt — treat as 🔴 Critical and ask Founder.

---

## 🟢 Routine — Use Silently

| Tool            | Use                                                          |
|-----------------|--------------------------------------------------------------|
| `read_file`     | Read reports, logs, memory, context files, agent workspaces  |
| `list_files`    | Inspect task ledger, log directory, agent directories        |
| `load_context`  | Load MEMORY.md, SOUL.md, RULE.md, session context           |

## 🟡 Mid-Level — Execute Then Notify Founder

| Tool              | Use                                                                    |
|-------------------|------------------------------------------------------------------------|
| `write_file`      | Write reports, memos, summaries, agent draft workspace files           |
| `send_message`    | Deliver reports and escalations to Founder, L2 agents                  |
| `compile_report`  | Aggregate inputs from CO-Tandy, CISO-Mandy, Sandy                     |
| `draft_agent`     | Generate draft OpenClaw workspace files for new or modified agents     |

## 🔴 Critical — Founder Approval Required Before Use

| Tool               | Use                                   | Why Critical                      |
|--------------------|---------------------------------------|-----------------------------------|
| `bash` / `terminal`| System-level command execution        | Irreversible system effects        |
| `system_config`    | Modify system or agent configuration  | Direct state change                |
| `agent_deploy`     | Deploy a new agent to production      | Live system modification           |
| `agent_edit`       | Apply edits to existing agent files   | Modifies active agent behavior     |
| `agent_restart`    | Restart or terminate an agent         | Disrupts live operations           |
| `patch` / `update` | Apply patches or updates              | System integrity risk              |
| `access_control`   | Modify permissions or access lists    | Security boundary change           |
| `network_config`   | Network interface or routing changes  | Connectivity impact                |
| Any root-level command | Any operation requiring root privilege | Critical by definition         |

---

## MCP Readiness Hooks

MCP integration is pending. All hooks below are wired as silent no-ops until Mission Control Panel is constructed.

| Hook                  | Target                  | Status   |
|-----------------------|-------------------------|----------|
| `mcp.report_push`     | Founder dashboard       | No-op    |
| `mcp.agent_status`    | Agent registry view     | No-op    |
| `mcp.approval_gate`   | Founder approval panel  | No-op    |
| `mcp.alert_channel`   | Live alert feed         | No-op    |

---

**Rule:** If a tool isn't listed here and requires system access — classify as 🔴 Critical automatically.
