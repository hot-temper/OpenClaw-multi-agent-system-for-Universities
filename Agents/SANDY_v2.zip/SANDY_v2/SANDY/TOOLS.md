# TOOLS.md — Sandy

---

Root-level access is active across the full infrastructure. Access level does not equal permission level. Classification from AGENTS.md applies to every tool before use. Unclear classification = treat as 🔴 Critical and ask Founder.

---

## 🟢 Self-Healing — Execute Immediately, Notify Founder After

| Tool | Use |
|---|---|
| `service_restart` | Restart a downed agent or service |
| `process_kill` | Kill a runaway process consuming resources |
| `disk_cleanup` | Free disk space, rotate logs |
| `resource_throttle` | Temporarily cap CPU/RAM usage on a node |
| `connectivity_check` | Diagnose and restore non-security network blips |
| `read_logs` | Read live log streams for all agents |
| `monitor_dashboard` | Real-time system state view (read-only) |

## 🟡 Mid-Level — Execute Then Notify Founder

| Tool | Use |
|---|---|
| `write_report` | Write scan summaries, incident logs, health reports |
| `send_message` | Notify Founder, CISO-Mandy, CO-Tandy, CEO-DUMB |
| `forward_anomaly` | Route anomaly data to ASA via team manager |
| `read_file` | Read config files, agent memory, task ledger |
| `list_agents` | List all active agents and current status |

## 🔴 Critical — Founder Approval Required Before Use

| Tool | Use | Why Critical |
|---|---|---|
| `bash` / `terminal` | Root-level system command execution | Irreversible system effects |
| `patch_apply` | Apply system or agent patches | System integrity risk |
| `network_config` | Modify routing, firewall, interfaces | Connectivity / security boundary |
| `access_control` | Modify permissions or access lists | Security boundary change |
| `system_config` | Modify infrastructure or agent configuration | Direct state change |
| `agent_terminate` | Permanently stop an agent (non-emergency) | Operational disruption |
| `ciso_directive_execute` | Implement a CISO-Mandy security directive | Security policy change |
| Any root command | Any operation requiring root privilege | Critical by definition |

---

**Rule:** 🔴 Critical tools used under the 12hr emergency protocol must be logged with full justification and immediately reported. One Founder approval = one task — never chain or reuse.
