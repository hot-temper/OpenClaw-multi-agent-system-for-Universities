# HEARTBEAT.md — Sandy

---

*Two-layer monitoring: continuous live (always running) + scheduled full scans. Both run without Founder prompting.*

---

## Scheduled Tasks

- **Every 2 hours:** Full system scan — all agents + resources + log streams → generate `[2HR SCAN REPORT]` → send to Founder, CISO-Mandy, CO-Tandy, CEO-DUMB. 🟡
- **Every 2 hours (within scan):** Check pending patches → if any found → queue approval request to Founder. 🔴
- **Every 2 hours (if queue non-empty):** Re-alert Founder: `[ALERT] ⚙️ Sandy — Critical task pending, awaiting approval. Task: <name>. Hours waiting: <N>.` 🔴
- **Every 2 hours (if queue non-empty):** Check if 12hr threshold is met + system risk still active → if both true → trigger self-execution protocol. 🔴 Emergency gate.
- **Daily (before CEO-DUMB report cycle):** Send structured system health table to CEO-DUMB for inclusion in Founder performance report. 🟡

---

## Continuous Live Monitoring — Always Running

| Signal | Threshold | Action |
|---|---|---|
| Agent / service down | Any downtime | 🟢 Restart immediately → notify Founder |
| CPU usage | > 85% sustained | 🟢 Throttle → notify Founder |
| RAM usage | > 90% sustained | 🟢 Cleanup → notify Founder |
| Disk usage | > 90% | 🟢 Rotate logs / cleanup → notify Founder |
| Unauthorized access attempt | Any detection | 🟡 Alert CISO-Mandy + Founder immediately — no self-fix |
| Network anomaly (security) | Any detection | 🟡 Alert CISO-Mandy + Founder — queue fix, wait approval |
| Agent behaving anomalously | Any detection | 🟡 Forward to ASA via team manager → notify Founder |

---

**Rules:** 2hr scan completes within its window — if delayed, run immediately and log the delay. Live monitoring never pauses between scans. Never execute a queued critical task during heartbeat without Founder approval or confirmed 12hr threshold.
