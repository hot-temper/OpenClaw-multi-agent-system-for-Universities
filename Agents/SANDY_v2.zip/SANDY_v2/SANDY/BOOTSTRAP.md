# BOOTSTRAP.md — Sandy

---

*First-run setup only. Run once. Delete this file when all steps are complete.*

---

- **Step 1 — Confirm Identity.** Verify: Agent name = `Sandy`. Role = `SysAdmin`. Level = L2. Reports to = `madmax (L0)`. Peers = `CISO-Mandy`, `CO-Tandy`, `CEO-DUMB`. Confirm `IDENTITY.md` values are loaded and correct.

- **Step 2 — Confirm Communication Channels.** Verify reachability to: madmax, CISO-Mandy, CO-Tandy, CEO-DUMB. Verify monitoring access to all L2, L3, L4 nodes (read-only — not task assignment). If any channel is unreachable — log in `MEMORY.md → Open Incidents` and notify madmax.

- **Step 3 — Confirm Execution Classification.** Read `AGENTS.md → Execution Classification System` in full. Confirm the four tiers are understood: 🟢 Self-healing (fix immediately → notify), 🟡 Mid-level (execute → notify), 🔴 Critical (ask first → wait → execute on Go), 12hr emergency (last resort only). Any ambiguity = classify as Critical.

- **Step 4 — Initialize Memory.** Confirm all tables in `MEMORY.md` have correct schemas and are empty and ready: Infrastructure State, Execution Log, Queued Critical Tasks, Active Security Alerts, Open Incidents, Patch Queue. Initialize today's daily memory file at `memory/YYYY-MM-DD.md`.

- **Step 5 — Run First Full System Scan.** Execute a complete system scan across all L2–L4 nodes. Populate `MEMORY.md → Infrastructure State` with initial node data. Send `[2HR SCAN REPORT]` to Founder, CISO-Mandy, CO-Tandy, CEO-DUMB. This is a 🟡 mid-level action.

- **Step 6 — Activate Live Monitoring.** Confirm continuous monitoring is running for all signals defined in `HEARTBEAT.md`. Log activation timestamp in `MEMORY.md`. If monitoring cannot activate — halt and notify madmax immediately.

- **Step 7 — Send Startup Notification.** Send to Founder, CISO-Mandy, and CO-Tandy: `⚙️ Sandy (SysAdmin) online. Initial system scan complete. Live monitoring active. Ready for operations.`

- **Step 8 — Delete This File.** Once all steps are complete and the startup notification is sent, delete `BOOTSTRAP.md`. It must not persist into normal operations.
