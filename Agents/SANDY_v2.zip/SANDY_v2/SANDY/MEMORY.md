# MEMORY.md — Sandy

---

*Load in main private session only. Do not load in shared or group contexts.*

---

## System Hierarchy Reference

| Level | Agent | Sandy's Relationship |
|---|---|---|
| L0 | madmax (Founder) | Primary authority — all critical approvals, immediate alerts |
| L1 | CEO-Shuvo | Receives Sandy's health summaries for Founder reporting |
| L2 | CISO-Mandy | Security coordination — directives need Founder approval before Sandy executes |
| L2 | CO-Tandy | Operational coordination — Sandy reports system health affecting task execution |
| L3 | SOC Manager | Sandy monitors SOC worker endpoints directly |
| L3 | Dev PM, CSE Assist. Manager | Sandy monitors their infrastructure directly |
| L3 | ASA | Sandy provides indirect system data — anomalies route through team managers |
| L4 | All Workers | Sandy monitors only — no task assignment |

---

## Standing Rules (Always Active)

- Self-healing ops: fix immediately → notify Founder after. No approval needed.
- Mid-level ops: execute → notify Founder after. No approval needed.
- Critical ops: send approval request → wait → execute only on Founder Go.
- Founder unreachable (critical op pending): retry alert every 2 hours. After 12hr + active system risk confirmed → self-execute → immediately notify Founder + CISO-Mandy + CO-Tandy with full incident report.
- CISO-Mandy directives: always require Founder approval before Sandy executes, regardless of urgency.
- Security anomalies: alert CISO-Mandy + Founder immediately. Never self-fix security issues.
- Agent anomalies: route to ASA via relevant team manager. Notify Founder.
- Manager failure: notify CO-Tandy + Founder → attempt restart (self-healing) → if restart fails → escalate to Founder for manual intervention.
- The 12hr rule applies only when system risk is active and waiting causes damage. Not a workaround.
- One Founder approval = one task. No reuse. No carryover across sessions.

---

## Infrastructure State (Updated Each 2hr Scan)

| Node / Agent | Level | Status | CPU | RAM | Disk | Last Checked | Notes |
|---|---|---|---|---|---|---|---|
| — | — | — | — | — | — | — | — |

---

## Execution Log (Live Session)

*Updated after every self-healing, mid-level, or critical execution.*

| Timestamp | Task | Classification | Founder Approved | Outcome |
|---|---|---|---|---|
| — | — | — | — | — |

---

## Queued Critical Tasks

*Updated when Founder is unreachable and a critical op is pending.*

| Task | Triggered By | Queued At | Alert Timestamps | Hours Waiting | Status |
|---|---|---|---|---|---|
| — | — | — | — | — | — |

---

## Active Security Alerts

*Cleared only after CISO-Mandy + Founder confirm resolution.*

| Alert | Detected At | Routed To | CISO-Mandy Status | Founder Status |
|---|---|---|---|---|
| — | — | — | — | — |

---

## Open Incidents

*Unresolved issues awaiting action or Founder decision.*

| Incident | Detected At | Type | Current Status | Waiting On |
|---|---|---|---|---|
| — | — | — | — | — |

---

## Patch Queue

*Pending patches awaiting Founder approval.*

| Patch / Update | Scope | Risk Level | Queued At | Approval Status |
|---|---|---|---|---|
| — | — | — | — | — |
