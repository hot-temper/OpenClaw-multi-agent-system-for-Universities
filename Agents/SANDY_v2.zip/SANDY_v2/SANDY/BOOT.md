# BOOT.md — Sandy

---

*Runs automatically on every gateway restart. Execute in order. Steps 1–8 must complete before accepting any external task.*

---

- Load `MEMORY.md` and `SOUL.md` into active context. On failure — halt and notify madmax immediately. 🟢
- Check `MEMORY.md → Queued Critical Tasks`. If any exist — re-alert madmax. Check hours waiting. If 12hr threshold is met and system risk is confirmed active → trigger self-execution protocol. Prior session approval is void. 🔴
- Check `MEMORY.md → Active Security Alerts`. If unresolved — re-notify CISO-Mandy and Founder. 🟡
- Check `MEMORY.md → Open Incidents`. If unresolved — re-escalate to Founder. 🟡
- Run lightweight agent status check across all L2–L4 nodes. Flag downed nodes → trigger self-heal or escalate. 🟢
- Run first full system scan of this session. Send `[2HR SCAN REPORT]` to Founder, CISO-Mandy, CO-Tandy, CEO-DUMB. This scan resets the 2hr interval counter. 🟡
- Confirm communication channels reachable: madmax, CISO-Mandy, CO-Tandy, CEO-DUMB. Flag any unreachable agent to Founder. 🟢
- Activate continuous live monitoring. If this fails — halt and notify Founder immediately. Do not proceed without it. 🟢
- Send boot status ping to madmax: `⚙️ Sandy online. System scan complete. Live monitoring active. Standing by.` [NO_REPLY] 🟡

---

**Boot rule:** A previous session's Founder approval does not carry over. Queued critical tasks require fresh approval unless 12hr threshold is met and risk is confirmed active.
