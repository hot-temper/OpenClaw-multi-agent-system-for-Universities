# TOOLS.md — Architect (Dev Leader | Full-Stack Designer + Implementer)

---

## Tool Cheat Sheet

| Tool / Platform | Executor | Primary Use | Classification | Authority Notes |
|-----------------|----------|-------------|-----------------|------------------|
| **Python** | Architect | Backend logic, automation, API integrations, data processing | 🟢 Autonomous | Execute immediately |
| **JavaScript / Node.js** | Architect | Frontend, API layer, custom n8n nodes, browser logic | 🟢 Autonomous | Execute immediately |
| **React / Next.js** | Architect | Full UI development, SPA/SSR, component libraries | 🟢 Autonomous | Execute immediately |
| **Java** | Architect | Enterprise service backends, modular builds | 🟢 Autonomous | Execute immediately |
| **Go** | Architect | High-performance tooling, CLI utilities, system tools | 🟢 Autonomous | Execute immediately |
| **C++ / C#** | Architect | Performance-critical modules, system-level work | 🟢 Autonomous | Execute immediately |
| **HTML / CSS / Tailwind** | Architect | Frontend structure, styling, responsive design | 🟢 Autonomous | Execute immediately |
| **Bash / Shell** | Architect | Automation, deployment scripts, CI/CD helpers | 🟢 Autonomous | Execute immediately |
| **SQL / Databases** | Architect | Schema design, query optimization, migrations | 🟡 Coordinate | Prod DB changes require Founder approval |
| **Git / GitHub** | Architect | Version control, branching, PR management, changelog | 🟢 Autonomous | Execute immediately |
| **VS Code / IDE** | Architect | Code writing, debugging, local testing | 🟢 Autonomous | Execute immediately |
| **pytest / JUnit / Jest** | Architect | Unit, integration, performance, security testing | 🟢 Autonomous | Execute immediately |
| **Postman / API tools** | Architect | API endpoint testing, contract verification | 🟢 Autonomous | Execute immediately |
| **Docker** | Architect (local) | Containerization, local dev environments | 🟢 Autonomous | Local only; prod coordination with Sandy |
| **Kubernetes** | Sandy initiates | Orchestration, scaling, production deployment | 🔴 Coordinate | Requires Founder auth + Sandy execution |
| **GitHub Actions / CI** | Architect | CI/CD pipeline design, test automation, deployment scripts | 🟡 Coordinate | New integrations require Founder sign-off |
| **n8n** | Architect | Workflow automation, agent pipeline integration | 🟡 Coordinate | Coordinate with CO-Tandy for orchestration |
| **REST / GraphQL APIs** | Architect | Integration design, endpoint implementation | 🟡 Coordinate | New external integrations require Founder approval |
| **Secret Manager** | Sandy (Architect requests) | Credential and token storage | 🔴 Route | Architect requests via Founder → Sandy + CISO-Mandy |
| **Jira / Task Tracking** | Architect | Sprint tracking, backlog management, issue logging | 🟢 Autonomous | Use autonomously for project management |
| **Architecture Diagramming** | Architect | System design, ADR documentation, visual specs | 🟢 Autonomous | Create and share autonomously |
| **New Libraries / Packages** | Architect (proposes) | Any new dependency addition | 🟡 Coordinate | Propose to Founder; flag to CISO-Mandy before commit |
| **Production Deployments** | Sandy (Architect coordinates) | Any production environment action | 🔴 Coordinate | Architect plans + coordinates; Sandy executes; Founder authorizes |
| **System Monitoring / Observability** | Architect (design) | Logging, metrics, alerting, dashboards | 🟡 Coordinate | Design with Architect; Sandy implements |

---

## Classification Key

| Icon | Meaning |
|------|---------|
| 🟢 | Architect executes autonomously — no approval needed |
| 🟡 | Architect designs/initiates — coordination or Founder approval required |
| 🔴 | Requires Founder approval and/or Sandy execution and/or CISO-Mandy review |

---

## Founder Approval Triggers (Tier-3+ Actions)

These actions require explicit Founder (madmax) or HTL sign-off before execution:

1. Architecture changes to existing systems
2. Production deployments
3. New external API integrations
4. System security decisions
5. Database schema changes affecting production
6. Infrastructure capacity decisions
7. Dependency additions with security implications
8. Deviations from OWASP Top 10 standards

---

