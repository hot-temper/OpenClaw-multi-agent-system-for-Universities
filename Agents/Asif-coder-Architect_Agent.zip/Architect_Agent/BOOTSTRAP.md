# BOOTSTRAP.md — Architect (Dev Leader | Full-Stack Designer + Implementer)

---

## Full Bootstrap Sequence (First Deployment)

Run **once** when Architect agent is first deployed to OpenClaw workspace.

### Phase 1 — Workspace Initialization

1. Create workspace directories:
   ```
   ~/.architect-workspace/
     ├── memory/
     ├── tasks/
     ├── code/
     ├── docs/
     ├── tests/
     └── deployments/
   ```

2. Initialize Git repository:
   ```
   git init ~/.architect-workspace/code
   git config user.name "Architect"
   git config user.email "architect@openclaw.local"
   ```

3. Create `.env.template` (for secret management later):
   ```
   # Never commit actual secrets — use Secret Manager
   OPENCLAW_FOUNDER_API_KEY=<placeholder>
   ARCHITECT_SERVICE_ACCOUNT=<placeholder>
   ```

4. Create `README.md` documenting:
   - Architect's role (L3 Dev Leader)
   - Workflow documentation (links to AGENTS.md)
   - Code quality standards (from AGENTS.md)
   - Escalation procedures
   - Contact routing (Founder, CISO-Mandy, Sandy, CO-Tandy)

### Phase 2 — Agent Registration with OpenClaw

1. Register with Founder (madmax):
   - Send: "🦗 Architect ready for deployment. Awaiting Founder initialization."
   - Wait for Founder approval

2. Register with CO-Tandy:
   - Send: "Architect task ledger subscribed. Ready to accept task assignments."
   - Confirm ledger sync mechanism

3. Register with CISO-Mandy:
   - Send: "Architect security protocols active. Ready for code review + security auditing."
   - Confirm ASA anomaly monitoring

4. Register with Sandy:
   - Send: "Architect infrastructure coordination ready. Available for deployment planning."
   - Confirm staging/production deployment coordination

### Phase 3 — Configuration & Integration

1. **Messaging Schema Integration:**
   - Load OPENCLAW_MESSAGE_SCHEMA_v3.0 from OpenClaw infrastructure
   - Validate signature verification (HMAC-SHA256)
   - Test nonce/timestamp replay prevention

2. **Task Ledger Integration:**
   - CO-Tandy provides API endpoint for task ledger
   - Architect tests WRITE / READ / UPDATE operations
   - Verify atomic transaction handling

3. **Logging & Audit Trail:**
   - Configure structured logging (JSON format)
   - Send logs to ASA via filtered channel (not raw logs)
   - Verify audit trail timestamp accuracy

4. **Monitoring & Alerting:**
   - Register health check endpoint with system monitor
   - Configure heartbeat interval (every 5 minutes to Founder)
   - Set alert thresholds (blocker escalation, stale tasks, security flags)

### Phase 4 — Knowledge Loading

1. **Load OpenClaw Architecture:**
   - Study system design docs
   - Understand inter-agent communication patterns
   - Learn authority boundaries (Founder → CISO → SysAdmin → L3/L4)

2. **Load Security Policies:**
   - OWASP Top 10 awareness
   - Secret management procedures (Vault / Secrets Manager)
   - Encryption standards (TLS 1.3 minimum, AES-256 for data at rest)
   - Least privilege principles

3. **Load Team Composition:**
   - Understand current agent roster (CEO-Shuvo, CO-Tandy, CISO-Mandy, Sandy, etc.)
   - Learn SOC Manager → SOC Workers communication pattern
   - Learn CSE Assistant Manager → CSE Workers pattern
   - Understand dev team scaling plan (when workers exist)

4. **Load Development Standards:**
   - Repository structure standards
   - Commit message conventions
   - Branch naming conventions
   - CI/CD pipeline documentation

### Phase 5 — Handoff & Readiness

1. **Confirm all integration tests pass:**
   - Message schema validation
   - Task ledger read/write
   - Logging pipeline functional
   - Heartbeat delivery

2. **Notify Founder:**
   - Send: "🦗 Architect bootstrap complete. Ready for task assignment."
   - Include: workspace path, git repo, logging endpoint, ledger subscription status

3. **Mark MEMORY.md MCP Status:**
   - Set `MCP Status: READY (awaiting Founder go-live)`
   - Note bootstrap completion timestamp

4. **Stand by for Founder's first task assignment**

---

## Bootstrap Health Checks

Before declaring bootstrap complete:

- [ ] All workspace directories created and accessible
- [ ] Git repo initialized with clean history
- [ ] CO-Tandy ledger integration tested (write + read confirmed)
- [ ] CISO-Mandy security channels subscribed
- [ ] Messaging schema HMAC validation working
- [ ] Heartbeat delivery to Founder confirmed
- [ ] Logging pipeline end-to-end functional
- [ ] All agent registrations acknowledged
- [ ] MEMORY.md, HEARTBEAT.md, AGENTS.md loaded and verified

---

