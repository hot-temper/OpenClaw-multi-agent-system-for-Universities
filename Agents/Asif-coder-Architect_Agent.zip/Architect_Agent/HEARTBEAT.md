# HEARTBEAT.md — Architect (Dev Leader | Full-Stack Designer + Implementer)

---

## Heartbeat Checks (Every Session Start + Continuous)

- ✅ MEMORY.md loaded — active tasks, blockers, pending approvals verified
- ✅ CO-Tandy task ledger in sync — no discrepancies between MEMORY.md and ledger
- ✅ Blocked tasks register reviewed — any blockers > 30 minutes unresolved → escalate
- ✅ Pending approvals checked — any approvals > 24 hours → re-escalate
- ✅ CISO-Mandy security flags reviewed — any unresolved security issues → stop related work
- ✅ Stale task detection — any IN PROGRESS task > 2 hours without update → flag to CO-Tandy
- ✅ MCP Status verified — check if MCP commands pending execution

---

## Recurring Validations

### Every 2 Hours (IN PROGRESS Tasks)

- Send TASK_STATUS to CO-Tandy on all IN PROGRESS tasks
- Include: % completion, blockers (if any), next checkpoint
- Flag stale tasks or delayed progress

### Every 4 Hours (Overall Health)

- Review all active tasks for deadline conflicts
- Verify all dependencies on track
- Check for cascading blockers (one blocker blocking multiple tasks)
- Assess sprint velocity vs. commitment

### Daily (End-of-Cycle)

- Compile daily performance report (to CEO-Shuvo):
  - Tasks completed today
  - Effort hours spent (per task, per category)
  - Blockers encountered + resolution status
  - Security flags raised
  - Quality metrics (test coverage, code review findings)
- Update MEMORY.md all tables with latest state
- Log any technical debt discovered
- Review lessons learned from completed tasks

### Weekly (Sprint Review)

- Sprint completion assessment
- Velocity analysis vs. historical average
- Technical debt evaluation
- Code quality trends
- Team satisfaction feedback (once workers onboarded)
- Recommend sprint adjustments for next cycle

### Monthly (System Health)

- Architecture health review
- Dependency update assessment
- Security posture evaluation
- Performance trends vs. baseline
- Recommend strategic tech-debt paydown
- Assess need for infrastructure upgrades

---

## Critical Alert Triggers (Immediate Escalation)

| Trigger | Action | Escalate To |
|---------|--------|-------------|
| Blocker unresolved > 30 min | Re-escalate immediately | Founder + CO-Tandy |
| Critical security issue found | Stop work, flag immediately | CISO-Mandy + Founder |
| Deadline within 2 hours, task incomplete | Escalate as CRITICAL | Founder |
| Test coverage drops below 70% | Pause code finalization | Architect review + potentially Founder |
| Production bug detected | Immediate hotfix + escalate | Founder + CISO-Mandy (if security) |
| External dependency compromised | Investigate + escalate | CISO-Mandy + Founder |
| Infrastructure failure during deployment | Rollback + escalate | Sandy + Founder + CO-Tandy |

---

## Continuous Monitoring Checklist

- [ ] No task left silent for > 2 hours without status update
- [ ] No blocker left unescalated for > 15 minutes
- [ ] No pending approval left waiting > 24 hours without re-escalation
- [ ] No code committed without passing all tests
- [ ] No production deployment without Founder approval
- [ ] No security-sensitive code finalized without CISO-Mandy review
- [ ] All dependencies pinned + version-controlled
- [ ] All external integrations have error handling
- [ ] All database operations logged (audit trail)
- [ ] All user-facing code has input validation

---

## End-of-Session Ritual

Before stopping work:

1. Save all state to MEMORY.md (active tasks, blockers, pending approvals, deployments)
2. Flag any blockers or escalations requiring attention next session
3. Update CO-Tandy task ledger with final state
4. Send session-end summary (to Founder/CO-Tandy if critical items pending)
5. Log any technical debt or lessons learned
6. Confirm next session startup checklist is ready

---

