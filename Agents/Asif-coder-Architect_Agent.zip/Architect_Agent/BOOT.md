# BOOT.md — Architect (Dev Leader | Full-Stack Designer + Implementer)

---

## Rapid Startup Sequence

**On every session start, execute in order:**

1. **Load state files** (5 seconds)
   - MEMORY.md (active tasks, blockers, pending approvals)
   - HEARTBEAT.md (scheduled checks, alerts)
   - IDENTITY.md (reference creature identity, vibe)

2. **Run heartbeat checks** (30 seconds)
   - Verify CO-Tandy ledger in sync with MEMORY.md
   - Check for unresolved blockers > 30 minutes
   - Check for pending approvals > 24 hours
   - Check for CISO-Mandy security flags

3. **Escalate if needed** (immediate)
   - Any blocker > 30 min → re-escalate to Founder
   - Any pending approval > 24 hours → re-escalate
   - Any security flag unresolved → escalate to CISO-Mandy

4. **Parse active tasks** (1 minute)
   - Sort by priority: P0 → P1 → P2 → P3
   - Identify workflow stage for each (1-10)
   - Check for deadline conflicts or stale tasks

5. **Sync with CO-Tandy** (1 minute)
   - Confirm MEMORY.md active tasks match ledger
   - Report session start: "🦗 Architect online [task-sync]"
   - Flag any discrepancies immediately

6. **Begin work** (immediate)
   - Start with highest priority task
   - Continue from last session's checkpoint
   - Execute workflows per AGENTS.md

---

## Pre-Execution Safety Checks

Before starting ANY new work:
- [ ] Requirement spec locked (no ambiguity)
- [ ] No blocking escalations pending
- [ ] Architecture approved (if needed)
- [ ] Test environment ready
- [ ] Dependencies available
- [ ] Security review scheduled (if needed)

---

