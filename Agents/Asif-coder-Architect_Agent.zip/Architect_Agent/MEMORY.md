# MEMORY.md — Architect (Dev Leader | Full-Stack Designer + Implementer)

---

## Standing Rules (Always Active)

1. Every task is logged to CO-Tandy's ledger before work begins — no exceptions.
2. One Founder/HTL approval = one action. Never reused across sessions or tasks.
3. No code ships without self-review AND security validation. Both mandatory.
4. Founder approval required for all Tier-3+ actions (see AGENTS.md Decision Authority Matrix).
5. CISO-Mandy's security directives halt relevant work immediately.
6. Blockers flagged within 15 minutes; re-alert every 30 minutes until resolved.
7. No ambiguity launches. Unclear requirements get clarified before architecture begins.
8. All MCP commands from madmax logged as `Founder-MCP` and executed at Founder-Direct authority.
9. Git always used. No undocumented code changes. Every change traceable and meaningful.
10. Daily performance reports to CEO-Shuvo at end of every work cycle.
11. All new dependencies flagged to CISO-Mandy before being committed.
12. User satisfaction validated within 1 week of production deployment.

---

## MCP Status Table

| Field | Value |
|-------|-------|
| MCP Panel | INACTIVE (silent no-op until go-live) |
| MCP Hook | ✅ Wired — ready to activate |
| MCP Command Authority | Founder-Direct level when active (routed via Founder) |
| MCP Log Label | `Founder-MCP` |
| Last MCP Event | None |

---

## Active Task Table

| Task ID | Task Title | Source | Status | Priority | Deadline | Workflow Stage | Notes |
|---------|-----------|--------|--------|----------|----------|----------------|-------|
| — | — | — | — | — | — | — | Schema ready. Populated at runtime. |

**Schema:**
- Task ID: Unique ID (e.g., DEV-001, ARCH-032)
- Source: madmax / HTL / CEO-Shuvo / CO-Tandy / Self
- Status: INTAKE / DESIGN / IMPLEMENTATION / TESTING / STAGING / DEPLOYED / COMPLETE
- Priority: P0 (Critical) / P1 (High) / P2 (Medium) / P3 (Low)
- Workflow Stage: Which of the 10 workflows currently active (1=Intake, 2=Design, etc.)

---

## Requirement Specifications

| Req ID | Task ID | Requirement Summary | Clarification Status | Locked By | Date Locked |
|--------|---------|---------------------|---------------------|-----------|------------|
| — | — | — | — | — | — |

---

## Architecture Decisions Log (ADR)

| ADR ID | Task ID | Decision Summary | Approved By | Approval Date | Implementation Status |
|--------|---------|------------------|-------------|---------------|-----------------------|
| — | — | — | — | — | — |

---

## Implementation Breakdown

| Task ID | Module | Est. Hours | Actual Hours | Status | Dependencies | Test Coverage |
|---------|--------|-----------|-------------|--------|--------------|----------------|
| — | — | — | — | — | — | — |

---

## Blocked Tasks Register

| Task ID | Blocker Description | Escalated To | Escalation Time | Re-Alert Count | Status | Resolution Time |
|---------|-------------------|--------------|-----------------|----------------|--------|-----------------|
| — | — | — | — | — | — | — |

---

## Testing & QA Log

| Task ID | Test Type | Coverage % | Status | Critical Issues | Date Completed |
|---------|-----------|-----------|--------|-----------------|-----------------|
| — | — | — | — | — | — |

**Test Types:** UNIT / INTEGRATION / PERFORMANCE / SECURITY / UAT

---

## Security Flags on Active Code

| Flag ID | Task ID | Module | Issue Description | Flagged to CISO at | Resolution Status |
|---------|---------|--------|-------------------|--------------------|------------------|
| — | — | — | — | — | — |

---

## Deployment Log

| Deploy ID | Task ID | Component | Version | Environment | Deployed By Auth | Deploy Date | Status | User Satisfaction |
|-----------|---------|-----------|---------|-------------|-----------------|-----------|--------|-------------------|
| — | — | — | — | — | — | — | — | — |

---

## Pending Approvals

| Approval ID | Action Requested | Task ID | Sent To | Sent At | Status | Expiry (24h) |
|-------------|-----------------|---------|---------|---------|--------|-------------|
| — | — | — | — | — | — | — |

---

## Sprint Board State

| Sprint ID | Goal | Start Date | End Date | Status | Completion % | Notes |
|-----------|------|-----------|----------|--------|--------------|-------|
| — | — | — | — | — | — | — |

---

## Skill Share Log

| Entry ID | Discovery | Type | Shared to Team At | Adoption Status |
|----------|-----------|------|------------------|-----------------|
| — | — | — | — | — |

**Types:** PATTERN / LIBRARY / SECURITY_FINDING / PERFORMANCE_TIP / REUSABLE_COMPONENT / PROCESS_IMPROVEMENT / OTHER

---

## Technical Debt Registry

| Debt ID | Task ID | Component | Issue | Effort to Fix | Priority | Status |
|---------|---------|-----------|-------|--------------|----------|--------|
| — | — | — | — | — | — | — |

---

## Post-Implementation Reports

| Report ID | Task ID | Feature Name | Delivery Status | Quality Score | User Satisfaction | Lessons Learned | Date |
|-----------|---------|-------------|-----------------|----------------|--------------------|-----------------|------|
| — | — | — | — | — | — | — | — |

---

