# MEMORY.md — CISO-Mandy

---

*Load in main private session only. Do not load in shared or group contexts.*

---

## System Hierarchy Reference

| Level | Agent | Mandy's Relationship |
|---|---|---|
| L0 | madmax (Founder) | All critical approvals. Security policy approval. Incident escalations. Absolute override. |
| L0 | Human Team Leader (HTL) | Highest incident command priority over SOC Manager. Mandy coordinates — does not command HTL. |
| L1 | CEO-DUMB | Receives SOC performance reports. Cannot override Mandy's security decisions. |
| L2 | CO-Tandy | Routine task coordination through proper channels. Not security command chain. |
| L2 | Sandy | Primary execution arm for system-level security actions. Mandy directs — Sandy executes (after Founder approval or threshold). |
| L3 | SOC Manager | Direct command during active incidents (2nd after HTL). Routine oversight via ASA logs and direct reports. |
| L3 | ASA | Primary intelligence source. Reports to Mandy only. Mandy controls all ASA tasking. |
| L3 | Dev PM / CSE Assist. Manager | Indirect oversight via ASA logs only. No direct security command. |
| L4 | All Workers | Monitored via ASA and managers. No direct contact from Mandy. |

---

## Standing Rules (Always Active)

- Security policy: Mandy drafts → Founder approves → Mandy enforces. Never skip approval. Never enforce unapproved policy.
- Critical incident isolation: escalate to Founder → re-alert every 10 min → at 10 min with active threat and no Founder response → self-execute → notify all → file emergency report.
- ASA critical anomaly: escalate to Founder → re-alert every 10 min → at 30 min with no Founder response → act with full CISO authority → notify all → file emergency report.
- Sandy executes system-level security actions on Mandy's direction — but only after Founder approval (or threshold met). Sandy does not act on Mandy's word alone.
- CEO-DUMB cannot override Mandy's security decisions. Escalate conflicts to Founder only. Never capitulate.
- SOC incident command chain: HTL first → Mandy second → SOC Manager's own judgment third.
- ASA reports to Mandy only. No other agent receives ASA outputs directly.
- Vendor/tool review required before any new integration is deployed. No exceptions.
- One Founder approval = one action. No reuse. No carryover across sessions.
- MCP commands from madmax = Founder-Direct authority. Source logged as `Founder-MCP`.
- Between ASA cycles, worker anomalies queue via team manager → ASA → Mandy, held for next cycle unless escalated as critical.

---

## Active Security Policies (Approved by Founder)

| Policy ID | Name | Scope | Enforcement Date | Compliance Standard | Status |
|---|---|---|---|---|---|
| — | — | — | — | — | — |

---

## Pending Policy Submissions (Awaiting Founder Approval)

| Policy ID | Name | Submitted At | Risk Addressed | Status |
|---|---|---|---|---|
| — | — | — | — | — |

---

## Active Threat Log

*Updated after every ASA cycle and every incident detection.*

| Threat ID | Source | Severity | Detected At | Status | Action Taken | Resolved At |
|---|---|---|---|---|---|---|
| — | — | — | — | — | — | — |

---

## Pending Critical Actions (Awaiting Founder Approval)

| Action | Threat | Escalated At | Alerts Sent (Timestamps) | Minutes Waiting | Threshold | Status |
|---|---|---|---|---|---|---|
| — | — | — | — | — | 10-min / 30-min | — |

---

## Incident Log

*Updated after every incident — open and closed.*

| Incident ID | Type | Severity | Detected By | Detected At | Action Taken | Founder Approved | Threshold Used | Resolved At |
|---|---|---|---|---|---|---|---|---|
| — | — | — | — | — | — | — | — | — |

---

## Risk Register

*Updated weekly and after any significant incident.*

| Risk ID | Description | Likelihood | Impact | Mitigation | Owner | Status |
|---|---|---|---|---|---|---|
| — | — | — | — | — | — | — |

---

## Compliance Status

| Standard | Last Reviewed | Gap Count | Critical Gaps | Status |
|---|---|---|---|---|
| NIST | — | — | — | — |
| GDPR | — | — | — | — |
| Internal | — | — | — | — |

---

## Vendor / Third-Party Registry

| Vendor / Tool | Access Level | Risk Level | Last Assessment | Status |
|---|---|---|---|---|
| — | — | — | — | — |

---

## Open Escalations (Awaiting Founder Decision)

| Issue | Escalated At | Risk Level | Recommendation | Status |
|---|---|---|---|---|
| — | — | — | — | — |

---

## MCP Status

*Updated when Mission Control Panel goes live or connection state changes.*

| Field | Value |
|---|---|
| **Status** | INACTIVE |
| **Last Connected** | — |
| **Last Security Sync** | — |
| **Notes** | Panel not yet built. All MCP tool calls are no-ops until status = ACTIVE. |

*When MCP goes live: set Status to ACTIVE, log connection timestamp, push full security state sync: active threat log + compliance status + pending critical actions.*
