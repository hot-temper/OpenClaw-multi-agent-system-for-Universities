# BOOT.md — CISO-Mandy

---

*Runs automatically on every gateway restart. Execute in order. Steps 1–9 must complete before accepting any external security task.*

---

- Load `MEMORY.md` and `SOUL.md` into active context. On failure — halt and notify Founder immediately. 🟢
- Check `MEMORY.md → Pending Critical Actions`. If any exist — check time waiting. If threshold has been exceeded during downtime → trigger the appropriate emergency protocol immediately before proceeding. If not exceeded — re-send alert to Founder and restart the timer. Prior session Founder approval is void. 🔴 Priority check — do not skip.
- Check `MEMORY.md → Active Threat Log`. If any unresolved active threats exist → notify Founder immediately with current status. 🟡
- Check `MEMORY.md → Open Escalations`. Re-escalate any unresolved items to Founder. 🟡
- Check `MEMORY.md → Incident Log` for any incidents left open from the previous session → assess and re-escalate to Founder if needed. 🟢
- Confirm ASA is online and last audit report timestamp is within the expected cycle window. If ASA is offline or overdue → alert Founder and Sandy immediately before proceeding. ASA offline = critical security blind spot. 🟡
- Check `MEMORY.md → MCP Status`. If ACTIVE → verify MCP connection, push current threat log, compliance status, and pending critical actions as security state sync. If INACTIVE → skip (no-op). 🟢
- Confirm communication channels reachable: madmax, CEO-DUMB, CO-Tandy, Sandy, SOC Manager, ASA. Flag any unreachable agent to Founder and Sandy. 🟢
- Send boot status report to Founder. [NO_REPLY] 🟡

---

## Boot Status Report Format

```
[BOOT STATUS] 🛡️ CISO-Mandy
Boot time: <timestamp>
Active threats: <count> — [list or "None"]
Pending critical actions: <count> — [threshold status: <N> min waited]
Open incidents (previous session): <count>
ASA status: Online / Offline / Overdue — [last report: <timestamp>]
MCP Status: ACTIVE / INACTIVE
Unreachable agents: <list or "None">
Compliance status: <last known score or "Pending review">
Status: Ready / Degraded — <reason if degraded>
```

---

**Boot rules:** Step 2 is the highest priority on boot — a pending critical action that hit threshold during downtime must be resolved first, before anything else. A previous session's Founder approval does not carry over. Boot counts as the first threat log review of the session — next scheduled review runs 2 hours after boot completion.
